package framework;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class ExcelDataRead {
	
	Fillo fillo;
	Connection connection;
	int currentIteration;
	int currentSubIteration;
	String currentTestcase;
	//String filePath="C:\\Users\\sxm226\\eclipse-workspace\\Send_XM_Post_Service";
	
	public void createExcelDataConnection(String filePath) {   //"C:\\Test.xlsx"
		fillo=new Fillo();
		try {
			connection=fillo.getConnection(filePath);
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void closeExcelDataConnection() {
		connection.close();
	}
	
	
	public Recordset getRecordSet(String strQuery) throws FilloException {
		Recordset recordset = connection.executeQuery(strQuery);
		return recordset;
	}
	

	public String getData(String datasheetName, String fieldName) throws FilloException {	
		String strQuery="Select " + fieldName + " from " + datasheetName +" where TC_ID = '"+ currentTestcase +"' and SubIteration='"+ currentSubIteration +"'";
		System.out.println(strQuery);
		Recordset recordset;
		recordset = connection.executeQuery(strQuery);

		String dataValue = "";
		while(recordset.next()){
			dataValue = recordset.getField(fieldName);
			System.out.println("Excel Data Read - "+"FieldName: "+fieldName + " Value: "+dataValue);
		}
		recordset.close();
		return dataValue;		
	}
	
	
	public void setCurrentRow(String currentTestcase, int currentIteration, int currentSubIteration) {
		this.currentTestcase = currentTestcase;
		this.currentIteration = currentIteration;
		this.currentSubIteration = currentSubIteration;
	}
	
	/**
	 * Function to retrieve the current sub-iteration number
	 */
	public int getCurrentRow() {
		return this.currentSubIteration;
	}

	/**
	 * Function to retrieve the current Iteration number
	 */
	public int getCurrentIterationRow() {
		return this.currentIteration;
	}
	
	public void putData(String datasheetName, String fieldName, String dataValue) throws FilloException {		
		String strQuery="Update "+datasheetName+" Set "+fieldName+"='"+dataValue+" where TC_ID = '"+ currentTestcase +"' and SubIteration='"+ currentSubIteration +"'"; 
		connection.executeUpdate(strQuery);
	}
	
	public void insertRow(String datasheetName, String fieldNames, String dataValues) throws FilloException {
		fieldNames = fieldNames.replace("|", ",");
		dataValues = dataValues.replace("|", "','");
		String strQuery="Insert into "+datasheetName+"("+fieldNames+") VALUES('"+ dataValues +"')";	 
		connection.executeUpdate(strQuery);
	}

}
