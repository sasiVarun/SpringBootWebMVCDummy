package framework;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

@SuppressWarnings("serial")
public class PropertiesFile extends Properties {

	Properties properties = new Properties();

	public void setProperties(String path) throws Exception {

		try {
			properties.load(new FileInputStream(path));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new Exception("FileNotFoundException while loading the Settings file");
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("IOException while loading the Settings file");
		}

	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

}
