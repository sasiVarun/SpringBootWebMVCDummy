package framework;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ReusableComponent {

	public String dateYearManipulation(String date, String dateYearMonthToAdd, Boolean flagToGetWeekDay) {

		SimpleDateFormat sdf;
		SimpleDateFormat sdfResult = new SimpleDateFormat("MM/dd/yyyy");
		Calendar c = Calendar.getInstance();

		if (date.contains("/"))
			sdf = new SimpleDateFormat("MM/dd/yyyy");
		else
			sdf = new SimpleDateFormat("MMddyyyy");

		if (date.equalsIgnoreCase("today")) {
			date = sdf.format(c.getTime());
			System.out.println("Today date " + date);
		}

		int dateYearDigit;
		int numOfdays;
		String dateCalc = "";

		if (!dateYearMonthToAdd.equals(""))
			dateCalc = dateYearMonthToAdd.substring(0, 1);
		if (dateCalc.equals("M")) {
			numOfdays = Integer.parseInt(dateYearMonthToAdd.substring(1));
			dateYearDigit = -numOfdays;
		} else if (dateCalc.equals("P")) {
			numOfdays = Integer.parseInt(dateYearMonthToAdd.substring(1));
			dateYearDigit = numOfdays;
		} else
			dateYearDigit = Integer.parseInt(dateYearMonthToAdd.replaceAll("[^-0-9.]", ""));

		dateYearMonthToAdd = dateYearMonthToAdd.toLowerCase();
		if (dateYearMonthToAdd.endsWith("y")) {
			try {
				c.setTime(sdf.parse(date));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			c.add(Calendar.YEAR, dateYearDigit);
		}

		else if (dateYearMonthToAdd.endsWith("m")) {
			try {
				c.setTime(sdf.parse(date));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			c.add(Calendar.MONTH, dateYearDigit);
		}

		else {
			try {
				c.setTime(sdf.parse(date));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			c.add(Calendar.DATE, dateYearDigit);
			if (flagToGetWeekDay) {
				int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
				if (dayOfWeek == Calendar.SUNDAY) {
					c.add(Calendar.DATE, 1);
				} else if (dayOfWeek == Calendar.SATURDAY) {
					c.add(Calendar.DATE, 2);
				}
			}
		}

		date = sdfResult.format(c.getTime());
		System.out.println("date :::: " + date);
		return date;

	}

}