package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;

public class CreateLP extends GlobalLibrary {
	
public CreateLP() {
		
	}

	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}

	public void createLP() throws InterruptedException, SOAPException, FilloException{
		System.out.println("i'm in createLP");

		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		ReusableComponent reusableComponent = new ReusableComponent();
		
		String reportDate;
		reportDate = excelDataTable.getData(LP_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);
		
		String totalClaimsFound = excelDataTable.getData(LP_Data, "Total_ClaimsFound");
		
		String addressLine1 = PartySearch.addressLine1;
		int pos = addressLine1.indexOf(' ');
		String houseNumber = addressLine1.substring(0, pos);
		String streetName = addressLine1.substring(pos + 1, addressLine1.length());
		
		
		String lpXML = "";
		lpXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:aut=\"http://service.amfam.com/riskreportsservice/automation\">"
				+"<soapenv:Header/>"
				+"<soapenv:Body>"
				+"<mes:insertLossPredictor mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\" mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\">"
				+"<mes:InsertLossPredictorRequest>"
				+"<aut:LossPredictorReport>"
				+"<aut:ReportCondition>"
				+"<aut:reportCondition>COMPLETE</aut:reportCondition>"
				+"</aut:ReportCondition>"
				+"<aut:ReportGeneralInfo>"
				+"<aut:reportOrderDate>"+ reportDate +"T17:27:47.978-06:00</aut:reportOrderDate>"
				+"<aut:reportReceivedDate>" + reportDate + "T17:27:47.978-06:00</aut:reportReceivedDate>"
				+"<aut:reportVendorName>TU</aut:reportVendorName>"
				+"<aut:dataSource>database</aut:dataSource>"
				+"</aut:ReportGeneralInfo>"
				+"<aut:OriginalOrderData>"
				+"<aut:Party>"
				+"<aut:Person>"
				+"<aut:SubjectData>"
				+"<aut:firstName>"+ PartySearch.firstName +"</aut:firstName>"
				+"<aut:middleName></aut:middleName>"
				+"<aut:lastName>"+ PartySearch.lastName +"</aut:lastName>"
				+"<aut:gender>U</aut:gender>"
				+"<aut:birthDate>"+ PartySearch.birthDate +"</aut:birthDate>"
				+"<aut:partyID>"+ PartySearch.partyIdentifier +"</aut:partyID>"
				+"<aut:socSecNumber></aut:socSecNumber>"
				+"</aut:SubjectData>"
				+"<aut:LicenseData>"
				+"<aut:licenseNumber>"+ PartySearch.licenseNumber +"</aut:licenseNumber>"
				+"<aut:licenseState>"+ PartySearch.licenseState +"</aut:licenseState>"
				+"</aut:LicenseData>"
				+"</aut:Person>"
				+"<aut:Address>"
				+"<aut:addressType>current</aut:addressType>"
				+"<aut:houseNumber>"+houseNumber+"</aut:houseNumber>"
				+"<aut:streetName>"+streetName+"</aut:streetName>"
				+"<aut:line1Text>"+ PartySearch.addressLine1 +"</aut:line1Text>"
				+"<aut:cityName>"+ PartySearch.city +"</aut:cityName>"
				+"<aut:stateCode>"+PartySearch.stateCode+"</aut:stateCode>"
				+"<aut:zip5Code>"+PartySearch.zip5Code+"</aut:zip5Code>"
				+"</aut:Address>"
				+"</aut:Party>"
				+"<aut:ScoreModel>"
				+"<aut:modelCode>00709</aut:modelCode>"
				+"<aut:characteristicType>RK_STATE</aut:characteristicType>"
				+"<aut:characteristicValue>"+PartySearch.stateCode+"</aut:characteristicValue>"
				+"</aut:ScoreModel>"
				+"</aut:OriginalOrderData>"
				+"<aut:LossPredictorData>"
				+"<aut:modelCode>00709</aut:modelCode>"
				+"<aut:status>defaultDelivered</aut:status>"
				+"<aut:totalClaimsFound>"+totalClaimsFound+"</aut:totalClaimsFound>"
				+"<aut:ClaimsData>"
				+"<aut:FilteredClaims><aut:claimCount>0</aut:claimCount><aut:scoreCard>F</aut:scoreCard></aut:FilteredClaims>"
				+"<aut:ExcludedClaims><aut:id>DTE_GT3Y</aut:id><aut:claimCount>0</aut:claimCount></aut:ExcludedClaims>"
				+"<aut:ExcludedClaims><aut:id>DTE_GT5Y</aut:id><aut:claimCount>0</aut:claimCount></aut:ExcludedClaims>"
				+"<aut:ExcludedClaims><aut:id>NUM_ROLE</aut:id><aut:claimCount>0</aut:claimCount></aut:ExcludedClaims>"
				+"</aut:ClaimsData>"
				+"</aut:LossPredictorData>"
				+"</aut:LossPredictorReport>"
				+"<aut:TransactionalData>"
				+"<aut:consumingSystemName>SOAPUI</aut:consumingSystemName>"
				+"<aut:consumerRequestPurpose>other</aut:consumerRequestPurpose>"
				+"<aut:userId>AQP506</aut:userId>"
				+"<aut:reportQualifyingAgeUnit>days</aut:reportQualifyingAgeUnit>"
				+"<aut:reportQualifyingAge>90</aut:reportQualifyingAge>"
				+"<aut:forceOrder>false</aut:forceOrder>"
				+"<aut:processingMode>Interactive</aut:processingMode>"
				+"<aut:returnErrorType>true</aut:returnErrorType>"
				+"<aut:userReferenceNumber>203940303</aut:userReferenceNumber>"
				+"</aut:TransactionalData>"
				+"</mes:InsertLossPredictorRequest>"
				+"<mes:Company><aut:companyCode>"+ companyCode +"</aut:companyCode>"
				+"<aut:division>Personal Lines</aut:division></mes:Company>"
				+"</mes:insertLossPredictor>"
				+"</soapenv:Body></soapenv:Envelope>";
		
		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(lpXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		
		reportInfo = doc.getElementsByTagNameNS("*","insertLossPredictorResponse");
		
	
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		System.out.println("LP Redport ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "LP" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		
	}

}
