package reportInsertion;

import java.time.format.DateTimeFormatter;
import framework.ExcelDataRead;
import framework.PropertiesFile;

public class GlobalLibrary {

	public static ExcelDataRead excelDataTable;
	public static PropertiesFile property;
	public static String testCaseName;
	public static int resetCurrentIteratioNo = 1;
	public static int resetCurrentSubIteration = 1;
	
	public String Driver_Data = "Driver_Data";
	public String ACL_Data = "ACL_Data";
	public String PCL_Data = "PCL_Data";
	public String PHR_Data = "PHR_Data";
	public String CBR_Data = "CBR_Data";
	public String Telematics_Data = "Telematics_Data";
	public String MVR_Data = "MVR_Data";
	public String DHR_Data = "DHR_Data";
	public String LP_Data  =  "LP_Data";
	public String VP_Data  =  "VP_Data";
	public String Results_Data = "Results_Data";

	public static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
	
	public static String FullName_PNI;
	public static String appln_Environment, appln_URL;
	public static String origin = "";
	public static String state = "";
	//public static String ssnNumber;
	//public static String ssnString;
	public static String driverLicenceNumber;
	public static String driverLicenceString;
	public static String policyEffDate;
	public static String companyCode;
	public static String partnerIdentifier;
}
