package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;

public class CreateDHR extends GlobalLibrary{
	
	public CreateDHR() {
		
	}

	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}

	public void createDHR() throws InterruptedException, SOAPException, FilloException{
		
		System.out.println("i'm in createDHR");

		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			RetrieveParty rp = new RetrieveParty();
			rp.retrieveParty();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}

		ReusableComponent reusableComponent = new ReusableComponent();
		
		String reportDate;
		reportDate = excelDataTable.getData(DHR_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);
					
		String setTagDHR = "";
		
		String policyNumber = excelDataTable.getData(DHR_Data, "Policy_Number");
		String subExpirationDateCode = excelDataTable.getData(DHR_Data, "Sub_ExpDate");
		String subExpirationDate = changeDateFormat(
				reusableComponent.dateYearManipulation("today", subExpirationDateCode, false));
		
		String licenseExpirationDate = "2025-11-01";
		//String licenseClassification = "D-NCOMM VEH";
		String licenseIssueDate = RetrieveParty.licenseYear + "-" + RetrieveParty.licenseMonth + "-01";
		String licenseStatus = "VALID";
		
		testCaseName = excelDataTable.getData(DHR_Data, "TC_ID");
		int DHRCount = Integer.parseInt(excelDataTable.getData(DHR_Data, "DHR_Count"));
		

		int currentSubIterationCount = excelDataTable.getCurrentRow();
		for (int i = 0; i < DHRCount; i++) {

				// To load the subIteration data's
				excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount + i);

				String violationTypeCode = excelDataTable.getData(DHR_Data, "DHR_TypeCode");
				String violationStateCode = excelDataTable.getData(DHR_Data, "DHR_StateCode");
				String violationVendorCode = excelDataTable.getData(DHR_Data, "DHR_VendorCode");
				String violationSuspensionDateCode = excelDataTable.getData(DHR_Data, "DHR_SuspenseDate");
				String violationConvictionDateCode = excelDataTable.getData(DHR_Data, "DHR_ConvictionDate");
				String violationDescription = excelDataTable.getData(DHR_Data, "DHR_Description");
				String driverPoint = excelDataTable.getData(DHR_Data, "CA_DriverPoint");
				String violationSuspensionDate = changeDateFormat(
						reusableComponent.dateYearManipulation("today", violationSuspensionDateCode, false));
				String violationConvictionDate = changeDateFormat(
						reusableComponent.dateYearManipulation("today", violationConvictionDateCode, false));
				
					setTagDHR += "<ns1:Violation><ns1:typeCode>" + violationTypeCode
							+ "</ns1:typeCode><ns1:stateViolationCode>"+violationStateCode
							+"</ns1:stateViolationCode><ns1:vendorViolationCode>" + violationVendorCode
							+ "</ns1:vendorViolationCode><ns1:americanFamilyViolationCode/>"
							+ "<ns1:violationSuspensionDate>" + violationSuspensionDate
							+ "</ns1:violationSuspensionDate><ns1:convictionReinstatementDate>"
							+ violationConvictionDate
							+ "</ns1:convictionReinstatementDate><ns1:pointsAssessed>" + driverPoint
							+ "</ns1:pointsAssessed><ns1:description>" + violationDescription
							+ "</ns1:description></ns1:Violation>\n";
		}
		String dhrXML="";
		dhrXML= "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:ns1=\"http://service.amfam.com/riskreportsservice/automation\">"
				+ "<soapenv:Header/>"
				+ "<soapenv:Body>"
				+"<mes:insertDriverHistory mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\" mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\">"
				+"<mes:InsertDriverHistoryRequest>"
				+"<ns1:DriverHistoryReport>"
				+"<ns1:ReportCondition>"
				+"<ns1:reportCondition>COMPLETE</ns1:reportCondition>"
				+"</ns1:ReportCondition>"
				+"<ns1:ReportGeneralInfo>"
				+"<ns1:reportOrderDate>"+ reportDate +"T17:27:47.978-06:00</ns1:reportOrderDate>"
				+"<ns1:reportReceivedDate>"+ reportDate +"T17:27:47.978-06:00</ns1:reportReceivedDate>"
				+"<ns1:reportVendorName>EXPLORE</ns1:reportVendorName>"
				+"</ns1:ReportGeneralInfo>"
				+"<ns1:OriginalOrderData>"
				+"<ns1:Person>"
				+"<ns1:SubjectData>"
				+"<ns1:firstName>"+ PartySearch.firstName +"</ns1:firstName>"
				+"<ns1:middleName></ns1:middleName>"
				+"<ns1:lastName>"+ PartySearch.lastName +"</ns1:lastName>"
				+"<ns1:gender>U</ns1:gender>"
				+"<ns1:birthDate>"+ PartySearch.birthDate +"</ns1:birthDate>"
				+"<ns1:partyID>"+ PartySearch.partyIdentifier +"</ns1:partyID>"
				+"</ns1:SubjectData>"
				+"<ns1:LicenseData>"
				+"<ns1:licenseNumber>"+ PartySearch.licenseNumber +"</ns1:licenseNumber>"
				+"<ns1:licenseState>"+ PartySearch.licenseState +"</ns1:licenseState>"
				+"</ns1:LicenseData>"
				+"</ns1:Person>"
				+"<ns1:Policy>"
				+"<ns1:policyNumber>"+policyNumber+"</ns1:policyNumber>"
				+"<ns1:expirationDate>"+subExpirationDate+"</ns1:expirationDate>"
				+"</ns1:Policy>"
				+"</ns1:OriginalOrderData>"
				+"<ns1:DriverHistoryData>"
				+"<ns1:Driver>"
				+"<ns1:Subject>"
				+"<ns1:firstName>"+ PartySearch.firstName +"</ns1:firstName>"
				+"<ns1:middleName></ns1:middleName>"
				+"<ns1:lastName>"+ PartySearch.lastName +"</ns1:lastName>"
				+"<ns1:gender>U</ns1:gender>"
				+"<ns1:birthDate>"+ PartySearch.birthDate +"</ns1:birthDate>"
				+"<ns1:partyID>"+ PartySearch.partyIdentifier +"</ns1:partyID>"
				+"<ns1:unparsedName>"+ PartySearch.firstName +" "+ PartySearch.lastName +"</ns1:unparsedName>"
				+"</ns1:Subject>"
				+"<ns1:Address>"
				+"<ns1:line1Text>"+ PartySearch.addressLine1 +"</ns1:line1Text>"
				+"<ns1:cityName>"+ PartySearch.city +"</ns1:cityName>"
				+"<ns1:stateCode>"+PartySearch.stateCode+"</ns1:stateCode>"
				+"<ns1:zip5Code>"+PartySearch.zip5Code+"</ns1:zip5Code>"
				+"</ns1:Address>"
				+"<ns1:License>"
				+"<ns1:expirationDate>" + licenseExpirationDate + "</ns1:expirationDate>"
				+"<ns1:classification>D-NCOMMVEH</ns1:classification>"
				+"<ns1:issueDate>" + licenseIssueDate + "</ns1:issueDate>"
				+"<ns1:restriction>GLASSES</ns1:restriction>"
				+"<ns1:licenseNumber>" + PartySearch.licenseNumber + "</ns1:licenseNumber>"
				+"<ns1:licenseState>" + PartySearch.licenseState + "</ns1:licenseState>"
				+"<ns1:licenseStatus>" + licenseStatus + "</ns1:licenseStatus>"
				+"</ns1:License>"
				+"</ns1:Driver>"+setTagDHR
				+"<ns1:miscellaneousText>MISC TEXT HERE</ns1:miscellaneousText>"
				+"</ns1:DriverHistoryData>"
				+"</ns1:DriverHistoryReport>"
				+"<ns1:TransactionalData>"
				+"<ns1:consumingSystemName>PBC</ns1:consumingSystemName>"
				+"<ns1:userId>test</ns1:userId>"
				+"</ns1:TransactionalData>"
				+"</mes:InsertDriverHistoryRequest>"
				+"<mes:Company>"
				+"<ns1:companyCode>" + companyCode + "</ns1:companyCode>"
				+"<ns1:division>Personal Lines</ns1:division>"
				+"</mes:Company>"
				+"</mes:insertDriverHistory>"
				+"</soapenv:Body>"
				+"</soapenv:Envelope>";
		
		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(dhrXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		try {
			reportInfo = doc.getElementsByTagNameNS("*","insertDriverHistoryResponse");
			
		} catch (Exception e) {
			//report.updateTestLog("DHR Report Insertion", "DHR Report added Failed", Status.DONE);
			e.printStackTrace();
		}
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		//String reportID = reportElement.getElementsByTagName("ns2:reportID").item(0).getTextContent();
		System.out.println("DHR Report ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "DHR" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		//report.updateTestLog("MVR Report Insertion", "MVR Report added with Report ID - " + reportID, Status.DONE);

	}

}
