package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;


public class CreateACL extends GlobalLibrary {

	private static String setOriginalTagACL;
	private static String claimFirstName;
	private static String claimLastName;
	private static String claimDOB;
	private static String claimPartyID;
	private static String claimSSN;
	private static String claimLicenseNum;
	private static String claimLicenseState;
	private static String addressLine1;
	private static String addressCity;
	private static String addressState;
	private static String zip5Code;
	private static String zip4Code;
	private static String houseNumber;
	private static String streetName;
	private static String claimPHFirstName = "";
	private static String claimPHLastName = "";
	private static String claimVOFirstName = "";
	private static String claimVOLastName = "";

	private static String pniData;
	private static String sniData;
	private static String otherData;

	public CreateACL() {
		
	}

	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}

	// Function to format the OriginalOrderData xml tags for PNI, SNI and Other
	// operator
	public String formatOriginalOrderDataXML() throws FilloException {

		//String[] ssnNum = ssnString.split("\\|");
		
		String[] licenceNumbers = driverLicenceString.split("\\|");
		String originalTagACL = "";

		for (int i = 1; i <= licenceNumbers.length; i++) {
			driverLicenceNumber = licenceNumbers[i - 1];
			try {
				PartySearch partySrch = new PartySearch();
				partySrch.partySearch();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SOAPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			claimFirstName = PartySearch.firstName;
			claimLastName = PartySearch.lastName;
			claimDOB = PartySearch.birthDate;
			claimPartyID = PartySearch.partyIdentifier;
			//claimSSN = PartySearch.ssnNumber;
			claimLicenseNum = PartySearch.licenseNumber;
			claimLicenseState = PartySearch.licenseState;
			addressLine1 = PartySearch.addressLine1;
			addressCity = PartySearch.city;
			addressState = PartySearch.stateCode;
			zip5Code = PartySearch.zip5Code;
			zip4Code = PartySearch.zip4Code;
			int pos = addressLine1.indexOf(' ');
			houseNumber = addressLine1.substring(0, pos);
			streetName = addressLine1.substring(pos + 1, addressLine1.length());

			originalTagACL += "<ns1:OriginalOrderData><ns1:Person><ns1:correlationIdentifier>"
					+ "1"
					+ "</ns1:correlationIdentifier><ns1:SubjectData><ns1:prefixName></ns1:prefixName><ns1:suffixName></ns1:suffixName><ns1:firstName>"
					+ claimFirstName
					+ "</ns1:firstName><ns1:middleName></ns1:middleName><ns1:lastName>"
					+ claimLastName
					+ "</ns1:lastName><ns1:gender>M</ns1:gender><ns1:birthDate>"
					+ claimDOB
					+ "</ns1:birthDate><ns1:partyID>"
					+ claimPartyID
					+ "</ns1:partyID><ns1:socSecNumber>"
					//+ claimSSN
					+ "</ns1:socSecNumber></ns1:SubjectData><ns1:LicenseData><ns1:licenseNumber>"
					+ claimLicenseNum
					+ "</ns1:licenseNumber><ns1:licenseState>"
					+ claimLicenseState
					+ "</ns1:licenseState></ns1:LicenseData></ns1:Person><ns1:Address><ns1:addressType>current</ns1:addressType><ns1:houseNumber>"
					+ houseNumber + "</ns1:houseNumber><ns1:streetName>" + streetName
					+ "</ns1:streetName><ns1:cityName>"
					+ addressCity + "</ns1:cityName><ns1:stateCode>" + addressState + "</ns1:stateCode><ns1:zip5Code>"
					+ zip5Code + "</ns1:zip5Code><ns1:zip4Code>" + zip4Code
					+ "</ns1:zip4Code></ns1:Address></ns1:OriginalOrderData>\n";

			if (i == 1) // PNI person
			{
				pniData = claimFirstName + "|" + claimLastName + "|" + claimDOB + "|" + claimPartyID + "|" + claimSSN
						+ "|" + claimLicenseNum + "|" + claimLicenseState + "|" + houseNumber + "|" + streetName + "|"
						+ addressCity + "|" + addressState + "|" + zip5Code + "|" + zip4Code;
			} else if (i == 2) // Other Person
			{
				otherData = claimFirstName + "|" + claimLastName + "|" + claimDOB + "|" + claimPartyID + "|" + claimSSN
						+ "|" + claimLicenseNum + "|" + claimLicenseState + "|" + houseNumber + "|" + streetName + "|"
						+ addressCity + "|" + addressState + "|" + zip5Code + "|" + zip4Code;
			} else if (i == 3) // SNI Person
			{
				sniData = claimFirstName + "|" + claimLastName + "|" + claimDOB + "|" + claimPartyID + "|" + claimSSN
						+ "|" + claimLicenseNum + "|" + claimLicenseState + "|" + houseNumber + "|" + streetName + "|"
						+ addressCity + "|" + addressState + "|" + zip5Code + "|" + zip4Code;
			}

		}
		return originalTagACL;

	}

	public void formatData(String policyHolder, String vehicleOperator) {
		String[] personData = new String[13];
		String[] vhData = new String[13];

		if (policyHolder.equalsIgnoreCase("PNI")) {
			personData = pniData.split("\\|");
		} else if (policyHolder.equalsIgnoreCase("Other")) {
			personData = otherData.split("\\|");
		} else if (policyHolder.equals("SNI")) {
			personData = sniData.split("\\|");
		}

		claimPHFirstName = personData[0];
		claimPHLastName = personData[1];
		claimDOB = personData[2];
		claimSSN = personData[4];
		claimLicenseNum = personData[5];
		claimLicenseState = personData[6];
		houseNumber = personData[7];
		streetName = personData[8];
		addressCity = personData[9];
		addressState = personData[10];
		zip5Code = personData[11];
		zip4Code = personData[12];

		if (vehicleOperator.equalsIgnoreCase("PNI")) {
			vhData = pniData.split("\\|");
		} else if (vehicleOperator.equalsIgnoreCase("Other")) {
			vhData = otherData.split("\\|");
		} else if (vehicleOperator.equals("") || vehicleOperator == null) {
			vhData[0] = "";
			vhData[1] = "";
		}

		claimVOFirstName = vhData[0];
		claimVOLastName = vhData[1];

	}

	public void createACL() throws InterruptedException, SOAPException, FilloException {

		System.out.println("i'm in createACL");

		setOriginalTagACL = formatOriginalOrderDataXML();

		ReusableComponent reusableComponent = new ReusableComponent();
	
		String reportDate;
		reportDate = excelDataTable.getData(ACL_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);
		
		String policyEffFullDate = reusableComponent.dateYearManipulation("today", policyEffDate, false);

		String claimPH;
		String claimVO;
		String claimDate;
		String claimtypeCode;
		String claimamount;
		String claimDispositionCode;
		String setTagACL = "";
		
		Random rand = new Random();
		
		int claimNumber = rand.nextInt(1000000000);
		int claimFileNumber = rand.nextInt(100000000)*10;
		
		System.out.println("Claim Number: "+ claimNumber+ "\n"+ "Claim File Number: "+claimFileNumber);

		String aclXML;
		testCaseName = excelDataTable.getData(ACL_Data, "TC_ID");
		int ACLCount = Integer.parseInt(excelDataTable.getData(ACL_Data, "ACL_Count"));

		int currentSubIterationCount = excelDataTable.getCurrentRow();
		for (int i = 0; i < ACLCount; i++) {

			String setClaimPayment = "";

			// To load the subIteration data's
			excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount + i);

			// Retrieve the data from ACL table for each iteration
			claimPH = excelDataTable.getData(ACL_Data, "PolicyHolder");
			claimVO = excelDataTable.getData(ACL_Data, "VehicleOperator");
			claimDate = excelDataTable.getData(ACL_Data, "ClaimDate");
			claimamount = excelDataTable.getData(ACL_Data, "ClaimAmount");
			claimtypeCode = excelDataTable.getData(ACL_Data, "ClaimTypeCode");
			claimDispositionCode = excelDataTable.getData(ACL_Data, "ClaimStatus");

			if (state.equals("OR") || state.equals("KS") || state.equals("CO") || state.equals("PA")) {
				if (claimDate.equals("M1700")) {
					claimDate = "M1000";
				}
			}
			claimDate = changeDateFormat(reusableComponent.dateYearManipulation(policyEffFullDate, claimDate, false));

			formatData(claimPH, claimVO);

			if (claimtypeCode.contains("#")) {
				String[] arrayClaimTypeCode = claimtypeCode.split("#");
				String[] arrayClaimAmount = claimamount.split("#");
				String[] arrayClaimDispositionCode = claimDispositionCode.split("#");
				for (int j = 0; j < arrayClaimTypeCode.length; j++) {

					setClaimPayment += "<ns1:ClaimPayment><ns1:typeCode>" + arrayClaimTypeCode[j]
							+ "</ns1:typeCode><ns1:amount>" + arrayClaimAmount[j] + "</ns1:amount><ns1:dispositionCode>"
							+ arrayClaimDispositionCode[j] + "</ns1:dispositionCode></ns1:ClaimPayment>";

				}
			} else {
				setClaimPayment = "<ns1:ClaimPayment><ns1:typeCode>" + claimtypeCode + "</ns1:typeCode><ns1:amount>"
						+ claimamount + "</ns1:amount><ns1:dispositionCode>" + claimDispositionCode
						+ "</ns1:dispositionCode></ns1:ClaimPayment>";
			}

			System.out.println("ClaimPayment tag:" + setClaimPayment);

			setTagACL += "<ns1:ClaimLossHistory><ns1:ClaimSummary><ns1:classification>CLSUB</ns1:classification><ns1:claimDate>"
					+ claimDate
					+ "</ns1:claimDate><ns1:claimNumber>"+claimNumber
					+ i
					+ "</ns1:claimNumber><ns1:claimFileNumber>"+claimFileNumber
					+ i
					+ "</ns1:claimFileNumber><ns1:AMBESTNumber>99017</ns1:AMBESTNumber><ns1:associationCode>P</ns1:associationCode><ns1:vehicleOperatorCode>N</ns1:vehicleOperatorCode><ns1:policyNumber>20080924990173948"
					+ i
					+ "</ns1:policyNumber><ns1:policyTypeCode>PA</ns1:policyTypeCode><ns1:insurerName>AMERICAN FAMILY INS</ns1:insurerName></ns1:ClaimSummary><ns1:ClaimParty><ns1:Person><ns1:SubjectData><ns1:classification>POLICYHOLDER</ns1:classification><ns1:firstName>"
					+ claimPHFirstName
					+ "</ns1:firstName><ns1:firstNameFlag>M</ns1:firstNameFlag><ns1:middleName></ns1:middleName><ns1:middleNameFlag>M</ns1:middleNameFlag><ns1:lastName>"
					+ claimPHLastName
					+ "</ns1:lastName><ns1:lastNameFlag>M</ns1:lastNameFlag><ns1:gender>M</ns1:gender><ns1:birthDate>"
					+ claimDOB
					+ "</ns1:birthDate><ns1:socSecNumber>"
					+ claimSSN
					+ "</ns1:socSecNumber><ns1:socSecNumberFlag>M</ns1:socSecNumberFlag></ns1:SubjectData><ns1:LicenseData><ns1:licenseNumber>"
					+ claimLicenseNum
					+ "</ns1:licenseNumber><ns1:licenseNumberFlag>M</ns1:licenseNumberFlag><ns1:licenseState>"
					+ claimLicenseState
					+ "</ns1:licenseState><ns1:licenseStateFlag>M</ns1:licenseStateFlag></ns1:LicenseData></ns1:Person><ns1:Address><ns1:addressType>MailingAddress</ns1:addressType><ns1:houseNumber>"
					+ houseNumber
					+ "</ns1:houseNumber><ns1:houseNumberFlag>M</ns1:houseNumberFlag><ns1:streetName>"
					+ streetName
					+ "</ns1:streetName><ns1:streetNameFlag>M</ns1:streetNameFlag><ns1:cityName>"
					+ addressCity
					+ "</ns1:cityName><ns1:cityNameFlag>M</ns1:cityNameFlag><ns1:stateCode>"
					+ addressState
					+ "</ns1:stateCode><ns1:stateCodeFlag>M</ns1:stateCodeFlag><ns1:zip5Code>"
					+ zip5Code
					+ "</ns1:zip5Code><ns1:zip5Flag>M</ns1:zip5Flag><ns1:zip4Code>"
					+ zip4Code
					+ "</ns1:zip4Code></ns1:Address></ns1:ClaimParty><ns1:ClaimParty><ns1:Person><ns1:SubjectData><ns1:classification>VEHICLE OPERATOR</ns1:classification><ns1:firstName>"
					+ claimVOFirstName
					+ "</ns1:firstName><ns1:firstNameFlag>D</ns1:firstNameFlag><ns1:lastName>"
					+ claimVOLastName
					+ "</ns1:lastName><ns1:lastNameFlag>D</ns1:lastNameFlag></ns1:SubjectData></ns1:Person></ns1:ClaimParty><ns1:ClaimVehicle><ns1:VehicleInfo><ns1:modelYear>1995</ns1:modelYear><ns1:model>TOYOTA CELICA</ns1:model><ns1:vehicleIDNumber>JT2AT00NXS0040007</ns1:vehicleIDNumber></ns1:VehicleInfo></ns1:ClaimVehicle>"
					+ setClaimPayment + "</ns1:ClaimLossHistory>\n";
		}

		// Reset sub iteration count to initial value
		excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount);

		aclXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:ns1=\"http://service.amfam.com/riskreportsservice/automation\">"
				+ "<soapenv:Header/>"
				+ "<soapenv:Body>"
				+ "<mes:insertAutoCLUE mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\" mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\">"
				+ "<mes:InsertAutoCLUERequest>" + "<ns1:AutoCLUEReport>" + "<ns1:ReportCondition>"
				+ "<ns1:reportCondition>COMPLETE</ns1:reportCondition>" + "</ns1:ReportCondition>"
				+ "<ns1:ReportGeneralInfo>" + "<ns1:reportOrderDate>"
				+ reportDate
				+ "T17:27:47.978-06:00</ns1:reportOrderDate>" + "<ns1:reportReceivedDate>" + reportDate
				+ "T17:27:47.978-06:00</ns1:reportReceivedDate>" + "<ns1:reportID></ns1:reportID>"
				+ "<ns1:reportVendorName>LexisNexis</ns1:reportVendorName>" + "</ns1:ReportGeneralInfo>"
				+ setOriginalTagACL + "<ns1:AutoCLUEData>" + "<ns1:Identity>"
				+ "<ns1:messageStatusCode>Success</ns1:messageStatusCode>" + "<ns1:reportType>B</ns1:reportType>"
				+ "<ns1:processingStatus>C</ns1:processingStatus>" + "<ns1:reportUsage>PA</ns1:reportUsage>"
				+ "<ns1:referenceNumber></ns1:referenceNumber>" + "<ns1:orderDate>2011-01-14</ns1:orderDate>"
				+ "<ns1:receiptDate>2011-01-14</ns1:receiptDate>"
				+ "<ns1:completionDate>2011-01-14</ns1:completionDate>"
				+ "<ns1:accountName>AMERICAN FAMILY MUTL INS</ns1:accountName>"
				+ "<ns1:accountNumber>464014TST</ns1:accountNumber>" + "<ns1:endTime>10:59:00.000</ns1:endTime>"
				+ "</ns1:Identity>" + "<ns1:ProcessingResult>" + "<ns1:itemCode>I</ns1:itemCode>"
				+ "<ns1:resultType>CL</ns1:resultType>" + "<ns1:resultStatus>Y</ns1:resultStatus>"
				+ "<ns1:resultCount>1</ns1:resultCount>" + "</ns1:ProcessingResult>" + "<ns1:ProcessingResult>"
				+ "<ns1:resultType>IH</ns1:resultType>" + "<ns1:resultStatus>X</ns1:resultStatus>"
				+ "<ns1:resultCount>0</ns1:resultCount>" + "</ns1:ProcessingResult>" + "<ns1:ProcessingResult>"
				+ "<ns1:resultType>AD</ns1:resultType>" + "<ns1:resultStatus>X</ns1:resultStatus>"
				+ "<ns1:resultCount>0</ns1:resultCount>" + "</ns1:ProcessingResult>" + "<ns1:ProcessingResult>"
				+ "<ns1:resultType>JU</ns1:resultType>" + "<ns1:resultStatus>N</ns1:resultStatus>"
				+ "<ns1:resultCount>0</ns1:resultCount>" + "</ns1:ProcessingResult>" + "<ns1:ProcessingResult>"
				+ "<ns1:itemCode>SJ</ns1:itemCode>" + "<ns1:resultType>CL</ns1:resultType>"
				+ "<ns1:resultStatus>Y</ns1:resultStatus>" + "<ns1:resultCount>1</ns1:resultCount>"
				+ "</ns1:ProcessingResult>" + "<ns1:ProcessingResult>" + "<ns1:resultType>IH</ns1:resultType>"
				+ "<ns1:resultStatus>X</ns1:resultStatus>" + "<ns1:resultCount>0</ns1:resultCount>"
				+ "</ns1:ProcessingResult>" + setTagACL + "</ns1:AutoCLUEData>" + "</ns1:AutoCLUEReport>"
				+ "<ns1:TransactionalData>" + "<ns1:consumingSystemName>soapUI_ACL</ns1:consumingSystemName>"
				+ "<ns1:consumerRequestPurpose>other</ns1:consumerRequestPurpose>"
				+ "<ns1:consumerTransactionID>12345</ns1:consumerTransactionID>" + "<ns1:userId>AGT200</ns1:userId>"
				+ "<ns1:orderId>54321</ns1:orderId>" + "</ns1:TransactionalData>" + "</mes:InsertAutoCLUERequest>"
				+ "<mes:Company>" + "<ns1:companyCode>" + companyCode + "</ns1:companyCode>"
				+ "<ns1:division>Personal Lines</ns1:division>" + "</mes:Company>" + "</mes:insertAutoCLUE>"
				+ "</soapenv:Body>" + "</soapenv:Envelope>";

		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(aclXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = doc.getElementsByTagNameNS("*","insertAutoCLUEResponse");
		//NodeList reportInfo = doc.getElementsByTagName("ns2:insertAutoCLUEResponse");
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		//String reportID = reportElement.getElementsByTagName("ns2:reportID").item(0).getTextContent();
		System.out.println("ACL Redport ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "ACL" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		//report.updateTestLog("ACL Report Insertion", "ACL Report added with Report ID - " + reportID, Status.DONE);

	}
}
