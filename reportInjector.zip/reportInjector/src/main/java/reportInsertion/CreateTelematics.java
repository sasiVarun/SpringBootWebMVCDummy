package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;

public class CreateTelematics extends GlobalLibrary {
	
	private static String addressLine1;
	private static String houseNumber;
	private static String streetName;

	public CreateTelematics() {

	}

//Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}

	public void createTelematics() throws InterruptedException, SOAPException, FilloException {
		System.out.println("i'm in createTelematics");

		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			RetrieveParty rp = new RetrieveParty();
			rp.retrieveParty();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}

		ReusableComponent reusableComponent = new ReusableComponent();
	
		String reportDate;
		reportDate = excelDataTable.getData(Telematics_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);

		//String policyEffFullDate = reusableComponent.dateYearManipulation("today", policyEffDate, false);

		String setOriginalOrderData = "";
		
		String setVehicleData = "";
		
		addressLine1 = PartySearch.addressLine1;
		
		int pos = addressLine1.indexOf(' ');
		houseNumber = addressLine1.substring(0, pos);
		streetName = addressLine1.substring(pos + 1, addressLine1.length());
		
		int VehicleCount = Integer.parseInt(excelDataTable.getData(Telematics_Data, "Vehicle_Count"));
		
		int currentSubIterationCount = excelDataTable.getCurrentRow();
		
		for (int i = 0; i < VehicleCount; i++) {

			// To load the subIteration data's
			excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount + i);

			String VIN = excelDataTable.getData(Telematics_Data, "VIN_Number");
			String Make = excelDataTable.getData(Telematics_Data, "Vehicle_Make");
			String Model = excelDataTable.getData(Telematics_Data, "Vehicle_Model");
			String Year = excelDataTable.getData(Telematics_Data, "Vehicle_Year");
			String Score = excelDataTable.getData(Telematics_Data, "Score");
			setOriginalOrderData += "<aut:VehicleData>"
					+"<aut:vehicleIdentificationNumber>"+VIN+"</aut:vehicleIdentificationNumber>"
					+"<aut:vehicleMake>"+Make+"</aut:vehicleMake>"
					+"<aut:vehicleModel>"+Model+"</aut:vehicleModel>"
					+"<aut:vehicleYear>"+Year+"</aut:vehicleYear>"
					+"<aut:riskState>"+PartySearch.stateCode+"</aut:riskState>"
					+"</aut:VehicleData>";
			
			setVehicleData += "<aut:Vehicle>"
					+"<aut:vehicleIdentificationNumber>"+VIN+"</aut:vehicleIdentificationNumber>"
					+"<aut:vehicleMake>"+Make+"</aut:vehicleMake>"
					+"<aut:vehicleModel>"+Model+"</aut:vehicleModel>"
					+"<aut:vehicleYear>"+Year+"</aut:vehicleYear>"
					+"<aut:enrollmentStatus>EN</aut:enrollmentStatus>"
					+"<aut:enrollmentDate>2019-10-11</aut:enrollmentDate><aut:productEnrollmentStatus>EN</aut:productEnrollmentStatus>"
					+"<aut:scoreStatus>SU</aut:scoreStatus><aut:scoreType>Current</aut:scoreType>"
					+"<aut:score>"+Score+"</aut:score>"
					+"<aut:scoreStartDate>2015-07-25</aut:scoreStartDate>"
					+"<aut:scoreEndDate>2025-10-11</aut:scoreEndDate>"
					+"<aut:PersonData><aut:SubjectData>"
					+"<aut:firstName>" + PartySearch.firstName + "</aut:firstName>"
					+"<aut:lastName>" + PartySearch.lastName + "</aut:lastName>"
					+"</aut:SubjectData></aut:PersonData>"
					+"<aut:AddressData>"
					+"<aut:line1Text>" + PartySearch.addressLine1 + "</aut:line1Text>"
					+"<aut:cityName>"+PartySearch.city +"</aut:cityName>"
					+"<aut:stateCode>"+PartySearch.stateCode + "</aut:stateCode>"
					+"<aut:zip5Code>"+PartySearch.zip5Code+"</aut:zip5Code>"
					+"</aut:AddressData>"
					+"</aut:Vehicle>";
			
	}
		
		String teleXML = "";
		
		teleXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:aut=\"http://service.amfam.com/riskreportsservice/automation\">"
				+"<soapenv:Header/>"
				+"<soapenv:Body>"
				+"<mes:insertTelematicsReport mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\" mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\">"
				+"<mes:InsertTelematicsReportRequest>"
				+"<aut:TelematicsReport>"
				+"<aut:ReportCondition>"
				+"<aut:reportCondition>COMPLETE</aut:reportCondition>"
				+"</aut:ReportCondition><aut:ReportGeneralInfo>"
				+"<aut:reportOrderDate>" + reportDate + "T17:27:47.978-06:00</aut:reportOrderDate>"
				+"<aut:reportReceivedDate>" + reportDate + "T17:27:47.978-06:00</aut:reportReceivedDate>"
				+"<aut:reportID>ICkF7pWDNh_lEzzsSl0wexcGohd</aut:reportID>"
				+"<aut:reportVendorName>VERISK</aut:reportVendorName>"
				+"<aut:dataSource>Database</aut:dataSource>"
				+"</aut:ReportGeneralInfo><aut:OriginalOrderData>"
				+"<aut:useTypeCode>NE</aut:useTypeCode>"
				+"<aut:PersonData><aut:SubjectData>"
				+"<aut:firstName>" + PartySearch.firstName + "</aut:firstName>"
				+"<aut:lastName>" + PartySearch.lastName + "</aut:lastName>"
				+"<aut:birthDate>" + PartySearch.birthDate + "</aut:birthDate>"
				+"<aut:partyID>" + PartySearch.partyIdentifier + "</aut:partyID>"
				+"</aut:SubjectData><aut:LicenseData/></aut:PersonData>"
				+"<aut:AddressData>"
				+"<aut:houseNumber>"+houseNumber+"</aut:houseNumber>"
				+"<aut:streetName>"+streetName+"</aut:streetName>"
				+"<aut:line1Text>" + PartySearch.addressLine1 + "</aut:line1Text>"
				+"<aut:cityName>" + PartySearch.city + "</aut:cityName>"
				+"<aut:stateCode>" + PartySearch.stateCode + "</aut:stateCode>"
				+"<aut:zip5Code>" + PartySearch.zip5Code+"</aut:zip5Code>"
				+"</aut:AddressData>"+setOriginalOrderData+"</aut:OriginalOrderData>"
				+"<aut:VehicleData>"+setVehicleData+"</aut:VehicleData>"
				+"</aut:TelematicsReport><aut:TransactionalData>"
				+"<aut:consumingSystemName>PC</aut:consumingSystemName>"
				+"<aut:consumerRequestPurpose>other</aut:consumerRequestPurpose>"
				+"<aut:userId>AQP506</aut:userId><aut:reportQualifyingAgeUnit>days</aut:reportQualifyingAgeUnit>"
				+"<aut:reportQualifyingAge>90</aut:reportQualifyingAge>"
				+"</aut:TransactionalData></mes:InsertTelematicsReportRequest>"
				+"<mes:Company><aut:companyCode>" + companyCode + "</aut:companyCode>"
				+"<aut:division>Personal Lines</aut:division>"
				+"</mes:Company></mes:insertTelematicsReport></soapenv:Body></soapenv:Envelope>";
	
		
		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(teleXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		try {
			reportInfo = doc.getElementsByTagNameNS("*","insertTelematicsReportResponse");
			
		} catch (Exception e) {
			//report.updateTestLog("Telematics Report Insertion", "Telematics Report added Failed", Status.DONE);
			e.printStackTrace();
		}
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		//String reportID = reportElement.getElementsByTagName("ns2:reportID").item(0).getTextContent();
		System.out.println("Telematics Report ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "Telematics" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		//report.updateTestLog("MVR Report Insertion", "MVR Report added with Report ID - " + reportID, Status.DONE);


}

}