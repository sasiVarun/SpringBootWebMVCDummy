package reportInsertion;

import java.util.Properties;

import javax.swing.JOptionPane;
import javax.xml.soap.SOAPException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

import framework.ExcelDataRead;
import framework.PropertiesFile;

public class reportInsertionComponent extends GlobalLibrary {

	public static void main(String args[]) throws Exception {

		String path = "./src/main/resources/";
		String settingPropertiesPath = path + "Settings.properties";
		String reportDataPath = path + "ReportsData.xlsx";

		property = new PropertiesFile();
		excelDataTable = new ExcelDataRead();
		property.setProperties(settingPropertiesPath);
		excelDataTable.createExcelDataConnection(reportDataPath);

		Properties systemProps = System.getProperties();
		String certPath = property.getProperty("CertPath");
		systemProps.put("javax.net.ssl.trustStore", certPath);
		System.setProperties(systemProps);

		reportInsertionComponent report = new reportInsertionComponent();
		report.iterateTestCase();

		excelDataTable.closeExcelDataConnection();

		JOptionPane.showMessageDialog(null, "Report Insertion Completed.");

	}

	public void iterateTestCase() throws FilloException, InterruptedException, SOAPException {
		String strQuery = "select * from Driver_Data";
		System.out.println(strQuery);
		Recordset recordset = excelDataTable.getRecordSet(strQuery);
		while (recordset.next()) {
			String executeFlag = recordset.getField("Execute");
			if ("Yes".equalsIgnoreCase(executeFlag)) {
				testCaseName = recordset.getField("TC_ID");
				appln_Environment = recordset.getField("Environment");
				state = recordset.getField("State");
				origin = recordset.getField("Origin");
				policyEffDate = recordset.getField("PolicyEffDate");
				// ssnNumber = recordset.getField("SSN_Number");
				// ssnString = ssnNumber;

				companyCode = recordset.getField("CompanyCode");

				driverLicenceNumber = recordset.getField("DriverLicenseNumber");
				driverLicenceString = driverLicenceNumber;

				// Initialize the iteration and sub-iteration number
				excelDataTable.setCurrentRow(testCaseName, 1, 1);

				String insertACL = recordset.getField("InsertACL");
				String insertMVR = recordset.getField("InsertMVR");
				String insertCBR = recordset.getField("InsertCBR");
				String insertTelematics = recordset.getField("InsertTele");
				String insertDHR = recordset.getField("InsertDHR");
				String insertLP = recordset.getField("InsertLP");
				String insertVP = recordset.getField("InsertVP");
				String insertPCL = recordset.getField("InsertPCL");

				// Verify InsertACL flag in the data sheet and trigger ACL report
				if (insertACL.equalsIgnoreCase("Y")) {
					CreateACL acl = new CreateACL();
					acl.createACL();
				}
				// Verify InsertMVR flag in the data sheet and trigger MVR report
				if (insertMVR.equalsIgnoreCase("Y")) {
					CreateMVR mvr = new CreateMVR();
					mvr.createMVR();
				}
				// Verify InsertCBR flag in the data sheet and trigger CBR report
				if (insertCBR.equalsIgnoreCase("Y")) {
					CreateCBR cbr = new CreateCBR();
					cbr.createCBR();
				}
				// Verify InsertTelematics flag in the data sheet and trigger Telematics report
				if (insertTelematics.equalsIgnoreCase("Y")) {
					CreateTelematics tele = new CreateTelematics();
					tele.createTelematics();
				}
				// Verify InsertDHR flag in the data sheet and trigger DHR report
				if (insertDHR.equalsIgnoreCase("Y")) {
					CreateDHR dhr = new CreateDHR();
					dhr.createDHR();
				}
				// Verify InsertLP flag in the data sheet and trigger LP report
				if (insertLP.equalsIgnoreCase("Y")) {
					CreateLP lp = new CreateLP();
					lp.createLP();
				}
				// Verify InsertLP flag in the data sheet and trigger LP report
				if (insertVP.equalsIgnoreCase("Y")) {
					CreateVP vp = new CreateVP();
					vp.createVP();
				}
				// Verify InsertPCL flag in the data sheet and trigger PCL report
				if (insertPCL.equalsIgnoreCase("Y")) {
					CreatePCL pcl = new CreatePCL();
					pcl.createPCL();
				}

			}
			excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, resetCurrentSubIteration);
		}

		recordset.close();
	}

}
