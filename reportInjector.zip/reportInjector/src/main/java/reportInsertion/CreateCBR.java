package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;


public class CreateCBR extends GlobalLibrary{
	
	String reportDate;
	String noHit;
	String Incomplete;
	String reportCondition;
	String fileHitIndicator;
	String sourceIndicator;
	String serviceStatus;
	String scoreModelConditionDetail;
	String deceased;
	String freeze;
	String noScore;
	String suppressed;
	String scoreIndicatorFlag;
	String creditScoreAccessPin;
	String suppressionIndicator;
	String score;
	
	public CreateCBR() {
		
		// TODO Auto-generated constructor stub
	}
	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}
	public void createCBR() throws SOAPException, FilloException{
		reportDate = excelDataTable.getData(CBR_Data, "reportDate");

		ReusableComponent reusableComponent = new ReusableComponent();
		// Calculating the policy effective date based on the input value
		reportDate = reusableComponent.dateYearManipulation("Today", reportDate, false);
		reportDate=changeDateFormat(reportDate);
		//logger.info("reportDate: " + reportDate);
		
		//CBR Report flow begins
		//logger.info("reportDate: " + reportDate);
		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			/*RetrieveParty rp = new RetrieveParty();
			rp.retrieveParty();*/

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Report Conditions
		noHit = excelDataTable.getData(CBR_Data, "noHit");
		Incomplete = excelDataTable.getData(CBR_Data, "Incomplete");
		deceased = excelDataTable.getData(CBR_Data, "deceased");
		freeze = excelDataTable.getData(CBR_Data, "freeze");
		noScore = excelDataTable.getData(CBR_Data, "noScore");
		suppressed = excelDataTable.getData(CBR_Data, "suppressed");
		score = excelDataTable.getData(CBR_Data, "score");
		//String producerCode = excelDataTable.getData(CBR_Data, "producerCode");
				
		//Parse Address to HouseNumber and StreetName
		String HouseAndStreet = PartySearch.addressLine1.toString().replace(" ",",");
		String[] arrHouseStreet = HouseAndStreet.split(",");
		String houseNumber= arrHouseStreet[0];
		String RemoveHouseNumber = PartySearch.addressLine1.toString().replace(arrHouseStreet[0] + " ","");
		String streetName= RemoveHouseNumber;
		
		String modelCode = excelDataTable.getData(CBR_Data, "ModelCode");
		
		if(modelCode.equalsIgnoreCase("AUTO"))
			modelCode = "00863";
		else if(modelCode.equalsIgnoreCase("PROPERTY"))
			modelCode = "00877";
		else if(modelCode.equalsIgnoreCase("AMFAM"))
			modelCode = "AMFAM";
		
		if ( noHit.toString().equalsIgnoreCase("Y") ){
		    reportCondition = "NOHIT";
		    fileHitIndicator = "N";
		    sourceIndicator = "I";
		}
		
		else if ( Incomplete.toString().equalsIgnoreCase("Y") ){
		    reportCondition = "INCOMPLETE";
		    serviceStatus="03";
		    scoreModelConditionDetail= "SERVICE_UNAVAILABLE";
		    fileHitIndicator = "Y";
		    sourceIndicator = "F";
		    score="0";
		}
		else {
		    reportCondition = "COMPLETE";
		    serviceStatus= "01";
		    scoreModelConditionDetail= "SUCCESS";
		    fileHitIndicator = "Y";
		    sourceIndicator = "F";
		}
		
		//Special CBRs: Deceased, Freeze, NoScore vs. Normal 
		if (deceased.toString().equalsIgnoreCase("Y") ){
		    scoreIndicatorFlag="2";
		    suppressionIndicator = "N";
		    creditScoreAccessPin= "";
		    score="0";
		}
		else if (freeze.toString().equalsIgnoreCase("Y") ){ 
		    suppressionIndicator = "F";
		    creditScoreAccessPin="12345678";
		    score="94";
		    scoreIndicatorFlag="";
		}
		else if (noScore.toString().equalsIgnoreCase("Y") ){
		    scoreIndicatorFlag= "3";
		    suppressionIndicator = "N";
		    creditScoreAccessPin="";
		    score= "0";
		}
		else if (suppressed.toString().equalsIgnoreCase("Y") ){
		    scoreIndicatorFlag="";
		    suppressionIndicator = "Y";
		    creditScoreAccessPin="";
		    score="0";
		}
		else {
		    suppressionIndicator = "N";
		    scoreIndicatorFlag="";
		    creditScoreAccessPin="";
		}
		
		
		
		String cbrXML = "";
		cbrXML ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:ns1=\"http://service.amfam.com/riskreportsservice/automation\">"
				+"<soapenv:Header/>"
				+"<soapenv:Body>"
				+"<mes:insertCredit mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\" mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\">"
				+"<mes:InsertCreditRequest>"
				+"<ns1:CreditReport ns1:attachSchemaSourceTool=\"harvest\" ns1:attachSchemaProject=\"riskreportsmanageservice\" ns1:attachSchemaVersion=\"1.0\">"
				+"<ns1:ReportCondition>"
				+"<ns1:reportCondition>"+reportCondition+"</ns1:reportCondition>"
				+"</ns1:ReportCondition>"
				+"<ns1:ReportGeneralInfo>"
				+"<ns1:reportOrderDate>"+reportDate+"T11:27:09.094-05:00</ns1:reportOrderDate>"
				+"<ns1:reportReceivedDate>"+reportDate+"T11:27:12.000-05:00</ns1:reportReceivedDate>"
				+"<ns1:reportID></ns1:reportID>"
				+"<ns1:reportVendorName>TransUnion</ns1:reportVendorName>"
				+"</ns1:ReportGeneralInfo>"
				+"<ns1:OriginalOrderData>"
				+"<ns1:Party>"
                +"<ns1:Person>"
                +"<ns1:correlationIdentifier></ns1:correlationIdentifier>"
                +"<ns1:SubjectData>"
                +"<ns1:firstName>"+ PartySearch.firstName +"</ns1:firstName>"
                +"<ns1:middleName></ns1:middleName>"
                +"<ns1:lastName>"+ PartySearch.lastName +"</ns1:lastName>"
                +"<ns1:gender>U</ns1:gender>"
                +"<ns1:birthDate>"+ PartySearch.birthDate +"</ns1:birthDate>"
                +"<ns1:partyID>"+ PartySearch.partyIdentifier +"</ns1:partyID>" 
                +"<ns1:creditScoreAccessPin>"+ creditScoreAccessPin +"</ns1:creditScoreAccessPin>"
                +"</ns1:SubjectData>"
                +"</ns1:Person>"
                +"<ns1:Address>"
                +"<ns1:addressType>current</ns1:addressType>"
                +"<ns1:houseNumber>"+ houseNumber +"</ns1:houseNumber>"
                +"<ns1:streetName>"+ streetName +"</ns1:streetName>"
                +"<ns1:cityName>"+ PartySearch.city +"</ns1:cityName>"
                +"<ns1:stateCode>"+ PartySearch.stateCode +"</ns1:stateCode>"
                +"<ns1:zip5Code>"+ PartySearch.zip5Code+"</ns1:zip5Code>"
                +"<ns1:zip4Code></ns1:zip4Code>"
                +"</ns1:Address>"
                +"</ns1:Party>"
                +"<ns1:ScoreModel>"
                +"<ns1:modelCode>"+modelCode+"</ns1:modelCode>"
                +"<ns1:characteristicType>STATE</ns1:characteristicType>"
                +"<ns1:characteristicValue>"+ PartySearch.stateCode +"</ns1:characteristicValue>"
                +"</ns1:ScoreModel>"
                +"</ns1:OriginalOrderData>"
                +"<ns1:CreditData>"
                +"<ns1:TransactionControl>"
                +"<ns1:billingAccountNumber>12121212</ns1:billingAccountNumber>"
                +"</ns1:TransactionControl>"
                +"<ns1:Subject>"
                +"<ns1:SubjectHeader>"
                +"<ns1:fileHitIndicator>"+ fileHitIndicator +"</ns1:fileHitIndicator>"
                +"<ns1:suppressionIndicator>"+ suppressionIndicator +"</ns1:suppressionIndicator>"
                +"<ns1:inFileSinceDate>1985-03-06</ns1:inFileSinceDate>"
                +"</ns1:SubjectHeader>"
                +"<ns1:SubjectPersonal>"
                +"<ns1:firstName>"+ PartySearch.firstName +"</ns1:firstName>"
                +"<ns1:middleName></ns1:middleName>"
                +"<ns1:lastName>"+ PartySearch.lastName +"</ns1:lastName>"
                +"<ns1:partyID>"+ PartySearch.partyIdentifier +"</ns1:partyID>"
                +"<ns1:socSecNumber></ns1:socSecNumber>" 
                +"<ns1:creditScoreAccessPin>"+ creditScoreAccessPin +"</ns1:creditScoreAccessPin>"
                +"</ns1:SubjectPersonal>"
                +"<ns1:SubjectAddress>"
                +"<ns1:sourceIndicator>"+ sourceIndicator +"</ns1:sourceIndicator>"
                +"<ns1:dateReported>2011-10-01</ns1:dateReported>"
                +"<ns1:AddressData>"
                +"<ns1:addressType>Personal</ns1:addressType>"
                +"<ns1:houseNumber>"+ houseNumber +"</ns1:houseNumber>"
                +"<ns1:streetName>"+ streetName +"</ns1:streetName>"
                +"<ns1:cityName>"+ PartySearch.city +"</ns1:cityName>"
                +"<ns1:stateCode>"+ PartySearch.stateCode +"</ns1:stateCode>"
                +"<ns1:zip5Code>"+ PartySearch.zip5Code +"</ns1:zip5Code>"
                +"<ns1:zip4Code></ns1:zip4Code>"
                +"</ns1:AddressData>"
                +"</ns1:SubjectAddress>"
                +"<ns1:SubjectEmployment>"
                +"<ns1:sourceIndicator>"+ sourceIndicator +"</ns1:sourceIndicator>"
                +"<ns1:onFileSinceDate>2011-10-01</ns1:onFileSinceDate>"
                +"<ns1:employerName>ACME</ns1:employerName>"
                +"<ns1:occupation>E</ns1:occupation>"
                +"</ns1:SubjectEmployment>"
                +"<ns1:SubjectEmployment>"
                +"<ns1:sourceIndicator>"+ sourceIndicator +"</ns1:sourceIndicator>"
                +"<ns1:onFileSinceDate>2011-10-01</ns1:onFileSinceDate>"
                +"<ns1:employerName>CO</ns1:employerName>"
                +"<ns1:occupation>CEO</ns1:occupation>"
                +"<ns1:EmploymentAddress>"
                +"<ns1:sourceIndicator>"+ sourceIndicator +"</ns1:sourceIndicator>"
                +"<ns1:dateReported>2011-07-01</ns1:dateReported>"
                +"<ns1:AddressData>"
                +"<ns1:addressType>Employment</ns1:addressType>"
                +"<ns1:stateCode>"+ PartySearch.stateCode +"</ns1:stateCode>"
                +"</ns1:AddressData>"
                +"</ns1:EmploymentAddress>"
                +"</ns1:SubjectEmployment>"
                +"</ns1:Subject>"
                + "<ns1:CreditScore><ns1:serviceStatus>"+serviceStatus+"</ns1:serviceStatus>"
                + "<ns1:scoreModelConditionDetail>"+scoreModelConditionDetail+"</ns1:scoreModelConditionDetail>"
                +"<ns1:serviceCode>"+modelCode+"</ns1:serviceCode>"
                + "<ns1:score>"+score+"</ns1:score>"
                + "<ns1:scoreIndicatorFlag>"+scoreIndicatorFlag+"</ns1:scoreIndicatorFlag>"
                + "<ns1:scoringFactor>058</ns1:scoringFactor><ns1:scoringFactor>062</ns1:scoringFactor></ns1:CreditScore><ns1:TradeAccountRatingTotal><ns1:accountRating1>1</ns1:accountRating1></ns1:TradeAccountRatingTotal><ns1:Trade><ns1:industryCode>D</ns1:industryCode><ns1:memberCode>0989D002</ns1:memberCode><ns1:updateMethodCode>A</ns1:updateMethodCode><ns1:effectiveDate>2011-05-07</ns1:effectiveDate><ns1:openedDate>1985-03-27</ns1:openedDate><ns1:subscriberName>BLOOM/FDSB</ns1:subscriberName><ns1:ecoaDesignator>I</ns1:ecoaDesignator><ns1:portfolioType>R</ns1:portfolioType><ns1:accountNumber>111112</ns1:accountNumber><ns1:accountType>CH</ns1:accountType><ns1:currentBalanceAmount>40</ns1:currentBalanceAmount><ns1:highCreditAmount>330</ns1:highCreditAmount><ns1:creditLimitAmount>2200</ns1:creditLimitAmount><ns1:termsMonthlyPaymentAmount>5</ns1:termsMonthlyPaymentAmount><ns1:currentAccountRating>01</ns1:currentAccountRating><ns1:paymentPatternStartDate>2011-04-07</ns1:paymentPatternStartDate><ns1:paymentPattern>1X111111</ns1:paymentPattern><ns1:numberMonthsReviewed>8</ns1:numberMonthsReviewed></ns1:Trade><ns1:Inquiry><ns1:industryCode>B</ns1:industryCode><ns1:memberCode>00140050</ns1:memberCode><ns1:subscriberName>CAPITAL ONE</ns1:subscriberName><ns1:inquiryECOADesignatorType>I</ns1:inquiryECOADesignatorType><ns1:dateOfInquiry>2008-06-20</ns1:dateOfInquiry></ns1:Inquiry>"
                +"</ns1:CreditData>"
                +"</ns1:CreditReport>"
                +"<ns1:TransactionalData xsi:type=\"ns1:CreditTransactionalDataType\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
        		+"<ns1:consumingSystemName>soapUI</ns1:consumingSystemName>"
        		+"<ns1:consumerRequestPurpose>other</ns1:consumerRequestPurpose>"
        		+"<ns1:userId>test</ns1:userId>"
        		+"</ns1:TransactionalData>"
        		+"</mes:InsertCreditRequest>"
        		+"<mes:Company>"
        		+"<ns1:companyCode>"+companyCode+"</ns1:companyCode>"
        		+"<ns1:division>Personal Lines</ns1:division>"
        		+"</mes:Company>"
        		+"</mes:insertCredit>"
        		+"</soapenv:Body>"
        		+"</soapenv:Envelope>";
		
		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(cbrXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		
		reportInfo = doc.getElementsByTagNameNS("*","insertCreditResponse");
		//reportInfo = doc.getElementsByTagName("ns2:insertCreditResponse");
	
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		//String reportID = reportElement.getElementsByTagName("ns2:reportID").item(0).getTextContent();
		System.out.println("CBR Redport ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "CBR" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
	}

}
