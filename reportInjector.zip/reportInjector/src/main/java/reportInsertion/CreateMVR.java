package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;


public class CreateMVR extends GlobalLibrary {

	public CreateMVR() {
		
	}

	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}

	public void createMVR() throws InterruptedException, SOAPException, FilloException {
		System.out.println("i'm in createMVR");

		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			RetrieveParty rp = new RetrieveParty();
			rp.retrieveParty();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}

		ReusableComponent reusableComponent = new ReusableComponent();
		
		String reportDate;
		reportDate = excelDataTable.getData(MVR_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);
		
		String policyEffFullDate = reusableComponent.dateYearManipulation("today", policyEffDate, false);
		
		String setTagMVR = "";

		String licenseExpirationDate = "2022-11-01";
		String licenseClassification = "D-NCOMM VEH";
		String licenseIssueDate = RetrieveParty.licenseYear + "-" + RetrieveParty.licenseMonth + "-01";
		String licenseStatus = "VALID";

		// Assigning the mvrDriverPoint, Driver points should be inserted only with CA state policy with CA license
		String mvrDriverPoint;
		// String LicenseState = dataTable.getData(Account_Data, "LicenseState");
		/* String LicenseState = driver.getTestParameters().getLicenseState();
		if (LicenseState.equalsIgnoreCase("CA")) {
			mvrDriverPoint = "Y";
		} else {
			mvrDriverPoint = "N";
		}  */
		mvrDriverPoint = "N";
		
		testCaseName = excelDataTable.getData(MVR_Data, "TC_ID");
		int MVRCount = Integer.parseInt(excelDataTable.getData(MVR_Data, "MVR_Count"));
		String mvrNoHit = excelDataTable.getData(MVR_Data, "MVR_NoHit");

		int currentSubIterationCount = excelDataTable.getCurrentRow();
		if (!mvrNoHit.equalsIgnoreCase("Y")) {
			for (int i = 0; i < MVRCount; i++) {

				// To load the subIteration data's
				excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount + i);

				String violationTypeCode = excelDataTable.getData(MVR_Data, "Violation_TypeCode");
				String violationVendorCode = excelDataTable.getData(MVR_Data, "Violation_VendorCode");
				String violationSuspensionDateCode = excelDataTable.getData(MVR_Data, "Violation_SuspenseDate");
				String violationConvictionDateCode = excelDataTable.getData(MVR_Data, "Violation_ConvictionDate");
				String violationDescription = excelDataTable.getData(MVR_Data, "Violation_Description");
				String driverPoint = excelDataTable.getData(MVR_Data, "CA_DriverPoint");
				String violationSuspensionDate = changeDateFormat(
						reusableComponent.dateYearManipulation(policyEffFullDate, violationSuspensionDateCode, false));
				String violationConvictionDate = changeDateFormat(
						reusableComponent.dateYearManipulation(policyEffFullDate, violationConvictionDateCode, false));

				if (mvrDriverPoint.equals("Y")) {
					setTagMVR += "<ns1:Violation><ns1:typeCode>" + violationTypeCode
							+ "</ns1:typeCode><ns1:vendorViolationCode>" + violationVendorCode
							+ "</ns1:vendorViolationCode><ns1:violationSuspensionDate>" + violationSuspensionDate
							+ "</ns1:violationSuspensionDate><ns1:convictionReinstatementDate>"
							+ violationConvictionDate
							+ "</ns1:convictionReinstatementDate><ns1:pointsAssessed>" + driverPoint
							+ "</ns1:pointsAssessed><ns1:description>" + violationDescription
							+ "</ns1:description></ns1:Violation>\n";
				} else {
					setTagMVR += "<ns1:Violation><ns1:typeCode>" + violationTypeCode
							+ "</ns1:typeCode><ns1:vendorViolationCode>" + violationVendorCode
							+ "</ns1:vendorViolationCode><ns1:violationSuspensionDate>" + violationSuspensionDate
							+ "</ns1:violationSuspensionDate><ns1:convictionReinstatementDate>"
							+ violationConvictionDate
							+ "</ns1:convictionReinstatementDate><ns1:description>" + violationDescription
							+ "</ns1:description></ns1:Violation>\n";
				}
			}

			// Reset sub iteration count to initial value
			excelDataTable.setCurrentRow(testCaseName, resetCurrentIteratioNo, currentSubIterationCount);

		}

		String mvrXML = "";
		mvrXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:ns1=\"http://service.amfam.com/riskreportsservice/automation\">"
				+ "<soapenv:Header/>"
				+ "<soapenv:Body>"
				+ "<mes:insertMotorVehicle mes:automationSchemaSourceTool=\"harvest\" mes:automationSchemaProject=\"riskreportsservice\" mes:automationSchemaVersion=\"4.0\"  mes:serviceSourceTool=\"harvest\" mes:serviceProject=\"riskreportsutilityservice\" mes:serviceVersion=\"4.0\" >"
				+ "<mes:InsertMotorVehicleRequest>"
				+ "<ns1:MotorVehicleReport>"
				+ "<ns1:ReportCondition>"
				+ "<ns1:reportCondition>COMPLETE</ns1:reportCondition>"
				+ "</ns1:ReportCondition>"
				+ "<ns1:ReportGeneralInfo>"
				+ "<ns1:reportOrderDate>" + reportDate + "T17:27:47.978-06:00</ns1:reportOrderDate>"
				+ "<ns1:reportReceivedDate>" + reportDate + "T17:27:47.978-06:00</ns1:reportReceivedDate>"
				+ "<ns1:reportVendorName>LexisNexis</ns1:reportVendorName>"
				+ "</ns1:ReportGeneralInfo>"
				+ "<ns1:OriginalOrderData>"
				+ "<ns1:Person>"
				+ "<ns1:correlationIdentifier>p1</ns1:correlationIdentifier>"
				+ "<ns1:SubjectData>"
				+ "<ns1:prefixName></ns1:prefixName>"
				+ "<ns1:suffixName></ns1:suffixName>"
				+ "<ns1:firstName>" + PartySearch.firstName + "</ns1:firstName>"
				+ "<ns1:middleName></ns1:middleName>"
				+ "<ns1:lastName>" + PartySearch.lastName + "</ns1:lastName>"
				+ "<ns1:gender>U</ns1:gender>"
				+ "<ns1:birthDate>" + PartySearch.birthDate + "</ns1:birthDate>"
				+ "<ns1:partyID>" + PartySearch.partyIdentifier + "</ns1:partyID>"
				+ "<ns1:socSecNumber></ns1:socSecNumber>"
				// " + PartySearch.ssnNumber + "</ns1:socSecNumber>"
				+ "</ns1:SubjectData>"
				+ "<ns1:LicenseData>"
				+ "<ns1:licenseNumber>" + PartySearch.licenseNumber + "</ns1:licenseNumber>"
				+ "<ns1:licenseState>" + PartySearch.licenseState + "</ns1:licenseState>"
				+ "</ns1:LicenseData>"
				+ "</ns1:Person>"
				+ "</ns1:OriginalOrderData>"
				+ "<ns1:MotorVehicleData>"
				+ "<ns1:Processing>"
				+ "<ns1:reportSource>Database</ns1:reportSource>"
				+ "<ns1:processDate>2012-12-24</ns1:processDate>"
				+ "<ns1:processingStatusCode>H</ns1:processingStatusCode>"
				+ "<ns1:sourceCode>I</ns1:sourceCode>"
				+ "<ns1:originCode>A</ns1:originCode>"
				+ "</ns1:Processing>"
				+ "<ns1:Driver>"
				+ "<ns1:Subject>"
				+ "<ns1:firstName>" + PartySearch.firstName + "</ns1:firstName>"
				+ "<ns1:middleName></ns1:middleName>"
				+ "<ns1:lastName>" + PartySearch.lastName + "</ns1:lastName>"
				+ "<ns1:gender>U</ns1:gender>"
				+ "<ns1:birthDate>" + PartySearch.birthDate + "</ns1:birthDate>"
				+ "<ns1:partyID>" + PartySearch.partyIdentifier + "</ns1:partyID>"
				+ "<ns1:socSecNumber></ns1:socSecNumber>"
				//+ PartySearch.ssnNumber + "</ns1:socSecNumber>"
				+ "</ns1:Subject>"
				+ "<ns1:Address>"
				+ "<ns1:addressType>RiskAddress</ns1:addressType>"
				+ "<ns1:line1Text>" + PartySearch.addressLine1 + "</ns1:line1Text>"
				+ "<ns1:cityStateZip>" + PartySearch.city + " " + PartySearch.stateCode + " " + PartySearch.zip5Code
				+ "</ns1:cityStateZip>"
				+ "</ns1:Address>"
				+ "<ns1:License>"
				+ "<ns1:expirationDate>" + licenseExpirationDate + "</ns1:expirationDate>"
				+ "<ns1:classification>" + licenseClassification + "</ns1:classification>"
				+ "<ns1:issueDate>" + licenseIssueDate + "</ns1:issueDate>"
				+ "<ns1:licenseNumber>" + PartySearch.licenseNumber + "</ns1:licenseNumber>"
				+ "<ns1:licenseState>" + PartySearch.licenseState + "</ns1:licenseState>"
				+ "<ns1:licenseStatus>" + licenseStatus + "</ns1:licenseStatus>"
				+ "</ns1:License>"
				+ "</ns1:Driver>"
				+ setTagMVR
				+ "</ns1:MotorVehicleData>"
				+ "</ns1:MotorVehicleReport>"
				+ "<ns1:TransactionalData>"
				/*
				 * + "<ns1:consumingSystemName>PC</ns1:consumingSystemName>"
				 * + "<ns1:consumerRequestPurpose>other</ns1:consumerRequestPurpose>"
				 * + "<ns1:userId>BTBT01</ns1:userId>"
				 * + "<ns1:reportQualifyingAgeUnit>days</ns1:reportQualifyingAgeUnit>"
				 * + "<ns1:reportQualifyingAge>90</ns1:reportQualifyingAge>"
				 * + "<ns1:forceOrder>false</ns1:forceOrder>"
				 */

				+ "<ns1:consumingSystemName>SIS Auto</ns1:consumingSystemName>"
				+ "<ns1:consumerRequestPurpose>quote</ns1:consumerRequestPurpose>"
				+ "<ns1:userId>EPS003</ns1:userId>"
				+ "<ns1:reportQualifyingAgeUnit>days</ns1:reportQualifyingAgeUnit>"
				+ "<ns1:reportQualifyingAge>180</ns1:reportQualifyingAge>"
				+ "<ns1:forceOrder>false</ns1:forceOrder>"

				+ "</ns1:TransactionalData>"
				+ "</mes:InsertMotorVehicleRequest>"
				+ "<mes:Company>"
				+ "<ns1:companyCode>" + companyCode + "</ns1:companyCode>"
				+ "<ns1:division>Personal Lines</ns1:division>"
				+ "</mes:Company>"
				+ "</mes:insertMotorVehicle>"
				+ "</soapenv:Body>"
				+ "</soapenv:Envelope>";

		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(mvrXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		try {
			reportInfo = doc.getElementsByTagNameNS("*","insertMotorVehicleResponse");
			//reportInfo = doc.getElementsByTagName("ns2:insertMotorVehicleResponse");
		} catch (Exception e) {
			//report.updateTestLog("MVR Report Insertion", "MVR Report added Failed", Status.DONE);
			e.printStackTrace();
		}
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		//String reportID = reportElement.getElementsByTagName("ns2:reportID").item(0).getTextContent();
		System.out.println("MVR Report ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "MVR" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		//report.updateTestLog("MVR Report Insertion", "MVR Report added with Report ID - " + reportID, Status.DONE);

	}

}
