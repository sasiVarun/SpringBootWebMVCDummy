package reportInsertion;

import javax.swing.JOptionPane;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;



public class PartySearch extends GlobalLibrary {

	public static String partyIdentifier;
	public static String firstName;
	public static String lastName;
	public static String birthDate;
	public static String licenseNumber;
	public static String licenseState;
	//public static String ssnNumber;
	public static String addressLine1;
	public static String city;
	public static String stateCode;
	public static String zip5Code;
	public static String zip4Code;
	public static String zip2Code;

	public PartySearch() {
		
	}

	public void partySearch() throws InterruptedException, SOAPException, FilloException {

		String partySearchXML;

		//ssnNumber = excelDataTable.getData(Driver_Data, "SSN_Number");
		//ssnNumber = ssnNumber.replace("-", "");
		//driverLicenceNumber = excelDataTable.getData(Driver_Data, "DriverLicenseNumber");
		
		getCompanyCode();

		partySearchXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:par=\"http://service.amfam.com/partysearchservice\" xmlns:par1=\"http://schema.amfam.com/party\">"
				+ "\n"
				+ "<soapenv:Header>"
				+ "\n"
				+ "<AppAuthzHeader>"
				+ "\n"
				+ "<userId>BTBT01</userId>"
				+ "\n"
				+ "</AppAuthzHeader>"
				+ "\n"
				+ "</soapenv:Header>"
				+ "\n"
				+ "<soapenv:Body>"
				+ "\n"
				+ "<par:searchParty par:automationSchemaSourceTool=\"CVS\" par:automationSchemaProject=\"PartyServiceCXFGenerator\" par:automationSchemaVersion=\"v4\" par:serviceSourceTool=\"CVS\" par:serviceProject=\"PartySearchService\" par:serviceVersion=\"4.0.279\">"
				+ "\n" + "<par:PartySearchRequest>"
				+ "\n" + "<par:PartySearchCriteria>"
				+ "\n" + "<par:PersonSearchCriteria>"
				+ "\n" + "<par:driversLicenseNumber>"+ driverLicenceNumber +"</par:driversLicenseNumber>"
				+ "\n" + "</par:PersonSearchCriteria>"	
				+ "\n" + "<par:AddressSearchCriteria><par:DomesticAddressSearchCriteria><par:stateCode>"+state+"</par:stateCode></par:DomesticAddressSearchCriteria></par:AddressSearchCriteria>"			
				+ "\n" + "<par:CommonSearchCriteria>"
				//+ "\n" + "<par:socialSecurityNumber>"
				//+ ssnNumber + "</par:socialSecurityNumber>"				
				+ "\n" + "</par:CommonSearchCriteria>"
				+ "\n" + "</par:PartySearchCriteria>"
				+ "\n" + "<par:partnerIdentifier>" + partnerIdentifier + "</par:partnerIdentifier>"
				+ "\n" + "<par:maxResults>50</par:maxResults>"
				+ "\n" + "<par:inBusinessProcess>true</par:inBusinessProcess>"
				+ "\n" + "</par:PartySearchRequest>"
				+ "\n" + "</par:searchParty>"
				+ "\n" + "</soapenv:Body>"
				+ "\n" + "</soapenv:Envelope>";

		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("PartySearchEndpointUrl_" + appln_Environment);
		System.out.println("PartySearchEndpointUrl: " + strEndpoint);

		// String strEndpoint = "https://intesb.amfam.com/ccx/cc-router/PartySearchService/06_01";
		// "https://accesb.amfam.com/ccx/cc-router/PartySearchService/06sit" ;

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(partySearchXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = doc.getElementsByTagName("ns1:PartySearchResponse");
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		
		// To get List with Same Driving License Number
		
		NodeList stateList = doc.getElementsByTagName("ns2:stateCode");
		//System.out.println("Total of elements : " + stateList.getLength());
		int i = 0;
		int flag = 0;
		 /*To insert report for Exact Contact if having multiple results 
								for same Driving License Number.*/
		if (stateList.getLength()>1) {
		for(i= 0 ; i<=stateList.getLength()-1;i++) {
			stateCode = reportElement.getElementsByTagName("ns2:stateCode").item(i).getTextContent();
			if(stateCode.equalsIgnoreCase(state)) {
				flag = 1;
				System.out.println("i value: "+i);
				break;
			}
		};
		
		}
		else {
			flag = 1;
		}
		if (flag == 1) {
		
		//System.out.println("i value inside: "+i);
		
	    partyIdentifier = reportElement.getElementsByTagName("ns1:partyIdentifier").item(i).getTextContent();
		firstName = reportElement.getElementsByTagName("ns1:firstName").item(i).getTextContent();
		lastName = reportElement.getElementsByTagName("ns1:lastName").item(i).getTextContent();
		birthDate = reportElement.getElementsByTagName("ns1:birthDate").item(i).getTextContent();
		licenseNumber = reportElement.getElementsByTagName("ns1:licenseNumber").item(i).getTextContent();
		licenseState = reportElement.getElementsByTagName("ns1:licenseState").item(i).getTextContent();
		addressLine1 = reportElement.getElementsByTagName("ns2:addressLine1").item(i).getTextContent();
		city = reportElement.getElementsByTagName("ns2:city").item(i).getTextContent();
		stateCode = reportElement.getElementsByTagName("ns2:stateCode").item(i).getTextContent();
		zip5Code = reportElement.getElementsByTagName("ns2:zip5Code").item(i).getTextContent();
		zip4Code = reportElement.getElementsByTagName("ns2:zip4Code").item(i).getTextContent();
		zip2Code = reportElement.getElementsByTagName("ns2:zip2Code").item(i).getTextContent();
		System.out.println("Party ID:"						+partyIdentifier 
							+ "\n" + "First Name: "			+ firstName 
							+ "\n" + "Last Name: " 			+ lastName 
							+ "\n" + "DOB: " 				+ birthDate 
							+ "\n" + "Driving License: " 	+ licenseNumber 
							+ "\n" + "State: " 				+ licenseState 
							+ "\n" + "Address Line1: " 		+ addressLine1 
							+ "\n" + "City:" 				+ city 
							+ "\n" + "State: " 				+ stateCode
							+ "\n" + "zip5Code: " 			+ zip5Code
							+ "\n" + "zip4Code: " 			+ zip4Code
							+ "\n" + "zip2Code: " 			+ zip2Code);

		// To retrieve the full name if Account is not created
		//if (AccountNumberSearch.equalsIgnoreCase("Y")) {
			
		//}
		FullName_PNI = firstName + " " + lastName;
		}
		
		// if State Code doesn't match with State in sheet gets terminated.
		else {
			excelDataTable.closeExcelDataConnection();
			JOptionPane.showMessageDialog(null,"Multiple Contacts retreived with given Driving Licnese. "
					+ "\n Given State \" " + state+ " \" is not present in retrieved list."
							+ " \n Kindly Update it.","Error",JOptionPane.ERROR_MESSAGE);
			//System.out.println("Please update the State in Drive Data sheet.");
			System.exit(0);
		}
		
	}

	public void getCompanyCode() throws InterruptedException, FilloException {
		
		//state = excelDataTable.getData(Driver_Data, "State");
		//String origin = excelDataTable.getData(Driver_Data, "Origin");
		
		//companyCode = excelDataTable.getData(Driver_Data, "CompanyCode");
		
		if (origin.contains("Wells"))
			partnerIdentifier = "500";
		else if (origin.contains("UWAA"))
			partnerIdentifier = "510";
		else if (origin.contains("MetLife"))
			partnerIdentifier = "138";
		else if (origin.contains("Matic"))
			partnerIdentifier = "514";
		else if (origin.contains("INSURITAS"))
			partnerIdentifier = "513";
		else if (origin.contains("Insurify"))
			partnerIdentifier = "520";
		else if (origin.contains("HomeGauge"))
			partnerIdentifier = "512";
		else if (origin.contains("Electric"))
			partnerIdentifier = "515";
		else if (origin.contains("Stuff")) //CoverMyStuff
			partnerIdentifier = "151";
		else if (origin.contains("Compare")) //Compare Auto
			partnerIdentifier = "521";
		else if (origin.contains("Direct")) //American Family Direct
			partnerIdentifier = "511";
		else if (origin.contains("Costco")) //Costco
			partnerIdentifier = "526";
		else
			partnerIdentifier = "AFI";  //American Family Insurance
		
		// Setting the company code for the report insertion based on the input states
		/* if (state.equals("OH") || state.equals("TX") || state.equals("TN") || state.equals("SC")) {
			companyCode = "AFMIC";
		} else if (state.equals("GA")) {
			companyCode = "ASICO";
		} else if (state.equals("NM") || state.equals("NJ") || state.equals("PA") || state.equals("CA")
				|| state.equals("MD") || state.equals("CT") || state.equals("NC") || state.equals("DE")
				|| state.equals("WY") || state.equals("MT") || state.equals("AL") || state.equals("AR")
				|| state.equals("VA") || state.equals("NH") || state.equals("NY") || state.equals("VT")
				|| state.equals("ME") || state.equals("OK") || state.equals("DC") || state.eq
uals("MS")
				|| state.equals("RI") || state.equals("LA") || state.equals("MA") || state.equals("KY")) {
			companyCode = "LCIC";
		} else {
			companyCode = "AFIC";
		} */
	}

}
