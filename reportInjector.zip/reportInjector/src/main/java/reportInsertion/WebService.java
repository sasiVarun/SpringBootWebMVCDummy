package reportInsertion;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;

//Executing WS Calls
public class WebService {

	XmlFormatter reqFormatter = new XmlFormatter();
	XmlFormatter respFormatter = new XmlFormatter();
	
	public SOAPMessage getSOAPRequest(String request) throws Exception {

		MessageFactory spFactory = MessageFactory.newInstance();

		// Create Soap request
		InputStream input = new ByteArrayInputStream(request.getBytes(Charset.forName("UTF-8")));
		SOAPMessage soapRequest = spFactory.createMessage(null, input);
		// id should be given
		soapRequest.getMimeHeaders().addHeader("Authorization", "Basic cWFsNDAxOnFhbDQwMQ==");

		// For printing the input
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		soapRequest.writeTo(out);
		String requestPrintMsg = new String(out.toByteArray());
		
		//XmlFormatter formatter = new XmlFormatter();
		
		System.out.println("Request:  " + reqFormatter.format(requestPrintMsg));

		return soapRequest;
	}

	public SOAPMessage getSOAPResponse(SOAPMessage soapRequest, String strEndpoint) throws Exception {

		// Send the SOAP request to the given end point and return the
		// corresponding response
		SOAPConnectionFactory spFactory = SOAPConnectionFactory.newInstance();
		SOAPConnection spCon = spFactory.createConnection();
		SOAPMessage spResp = spCon.call(soapRequest, strEndpoint);
		ByteArrayOutputStream outMsg = new ByteArrayOutputStream();
		spResp.writeTo(outMsg);
		String strMsg = new String(outMsg.toByteArray());
		
		String formatMsg = respFormatter.format(strMsg);

		//System.out.println("Response:  " + formatter.format(strMsg));
		System.out.println("Response:  " + formatMsg);

		// To retrieve the data from response
		/*
		 * Document doc = spResp.getSOAPBody().extractContentAsDocument(); NodeList reportInfo =
		 * doc.getElementsByTagName("ns2:insertCreditResponse"); Node reportData = reportInfo.item(0); Element
		 * reportElement = (Element) reportData; String reportID =
		 * reportElement.getElementsByTagName("ns2:reportID").item(0). getTextContent();
		 * System.out.println("Report ID: " + reportID);
		 */

		return spResp;
	}

	/**
	 * For testing
	 * 
	 * @param args
	 */
	public static void main(String args[]) {

		WebService obj = new WebService();

		// String strEndpoint =
		// "https://intesb.amfam.com/ccx/cc-router/RiskReportsUtilityService/v4_01";
		// //"https://accesb.amfam.com/ccx/cc-router/PartySearchService/06sit" ;
		// String soapReqPath =
		// "C:\\LISA_DATA\\GW_Project\\XML\\CBRRequest.xml";

		String strEndpoint = "https://intesb.amfam.com/ccx/cc-router/PartySearchService/06_01";
		String soapReqPath = "C:\\LISA_DATA\\GW_Project\\XML\\Search.xml";

		String inputRequest = "";
		try {
			inputRequest = new String(Files.readAllBytes(Paths.get(soapReqPath)));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			obj.getSOAPResponse(obj.getSOAPRequest(inputRequest), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
