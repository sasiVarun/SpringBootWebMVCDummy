package reportInsertion;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class RetrieveParty extends GlobalLibrary {

	public static String licenseYear;
	public static String licenseMonth;
	public static String gender;

	public RetrieveParty() {

	}

	public void retrieveParty() throws InterruptedException, SOAPException {
		// public static void main (String args[]) throws SOAPException{

		String retrievePartyXML;

		retrievePartyXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:par=\"http://service.amfam.com/partysearchservice\">"
				+ "\n" + "<soapenv:Header>"
				+ "\n" + "<AppAuthzHeader>"
				+ "\n" + "<userId>BTBT01</userId>"
				+ "\n" + "</AppAuthzHeader>"
				+ "\n" + "</soapenv:Header>"
				+ "\n" + "<soapenv:Body>"
				+ "\n"
				+ "<par:retrieveParty par:automationSchemaSourceTool=\"CVS\" par:automationSchemaProject=\"PartyServiceCXFGenerator\" par:automationSchemaVersion=\"v2\" par:serviceSourceTool=\"CVS\" par:serviceProject=\"PartySearchService\" par:serviceVersion=\"2.0.265\">"
				+ "\n" + "<par:RetrieveRequest>"
				+ "\n" + "<par:RetrieveCriteria>"
				+ "\n" + "<par:partyIdentifier>" + PartySearch.partyIdentifier + "</par:partyIdentifier>" // 3044218
				+ "\n" + "<par:LevelOfDetail>DEMOGRAPHIC_INFORMATION</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>ADDITIONAL_INFORMATION</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>IDENTITY_INFORMATION</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>EMPLOYMENT</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>ALTERNATE_NAMES</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>ADDRESSES</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>PHONES</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>EMAILS</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>TPI_INFORMATION</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>LIFE_EVENTS</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>SOCIAL_MEDIA</par:LevelOfDetail>"
				+ "\n" + "<par:LevelOfDetail>PARTY_RELATIONSHIPS</par:LevelOfDetail>"
				+ "\n" + "</par:RetrieveCriteria>"
				+ "\n" + "<par:consumer>SoapUI</par:consumer>"
				+ "\n" + "</par:RetrieveRequest>"
				+ "\n" + "</par:retrieveParty>"
				+ "\n" + "</soapenv:Body>"
				+ "\n" + "</soapenv:Envelope>";

		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("PartySearchEndpointUrl_" + appln_Environment);
		System.out.println("PartySearchEndpointUrl_" + strEndpoint);

		// String strEndpoint = "https://intesb.amfam.com/ccx/cc-router/PartySearchService/06_01";
		// "https://accesb.amfam.com/ccx/cc-router/PartySearchService/06sit" ;

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(retrievePartyXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = doc.getElementsByTagName("ns1:RetrieveResponse");
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		licenseYear = reportElement.getElementsByTagName("ns2:licenseYearString").item(0).getTextContent();
		licenseMonth = reportElement.getElementsByTagName("ns2:licenseMonthString").item(0).getTextContent();
		gender = reportElement.getElementsByTagName("ns2:Gender").item(0).getTextContent();
		// System.out.println("Report ID: " + licenseYear + "\n" + licenseMonth );
	}
}
