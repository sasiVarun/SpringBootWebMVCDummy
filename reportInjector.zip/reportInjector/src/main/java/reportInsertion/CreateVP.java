package reportInsertion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.codoid.products.exception.FilloException;

import framework.ReusableComponent;

public class CreateVP extends GlobalLibrary{

public CreateVP() {
		
	}

	// Function to format the date in required format
	public String changeDateFormat(String cDate) {
		SimpleDateFormat oldFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date subDate = null;
		try {
			subDate = oldFormat.parse(cDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newFormat.format(subDate);
	}
	
	public void createVP() throws InterruptedException, SOAPException, FilloException{

		System.out.println("i'm in createVP");

		try {
			PartySearch ps = new PartySearch();
			ps.partySearch();
			
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		ReusableComponent reusableComponent = new ReusableComponent();
		
		String reportDate;
		reportDate = excelDataTable.getData(VP_Data, "reportDate");
		reportDate = reusableComponent.dateYearManipulation("today", reportDate, false);
		reportDate = changeDateFormat(reportDate);
		
		String orderMVR = excelDataTable.getData(VP_Data, "Order_MVR");
		
		String vpXML="";
		vpXML="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mes=\"http://service.amfam.com/riskreportsutilityservice/message\" xmlns:aut=\"http://service.amfam.com/riskreportsservice/automation\">"
				+"<soapenv:Header/>"
				+"<soapenv:Body>"
				+"<mes:insertViolationPredictor>"
				+"<mes:InsertViolationPredictorRequest>"
				+"<aut:ViolationPredictorReport>"
				+"<aut:ReportCondition>"
				+"<aut:reportCondition>COMPLETE</aut:reportCondition>"
				+"</aut:ReportCondition>"
				+"<aut:ReportGeneralInfo>"
				+"<aut:reportOrderDate>"+ reportDate +"T17:27:47.978-06:00</aut:reportOrderDate>"
				+"<aut:reportReceivedDate>"+ reportDate +"T17:27:47.978-06:00</aut:reportReceivedDate>"
				+"<aut:reportVendorName>EXPLORE</aut:reportVendorName>"
				+"<aut:dataSource>Bureau</aut:dataSource>"
				+"</aut:ReportGeneralInfo>"
				+"<aut:OriginalOrderData>"
				+"<aut:Person>"
				+"<aut:SubjectData>"
				+"<aut:firstName>"+ PartySearch.firstName +"</aut:firstName>"
				+"<aut:middleName/>"
				+"<aut:lastName>"+ PartySearch.lastName +"</aut:lastName>"
				+"<aut:gender>U</aut:gender>"
				+"<aut:birthDate>"+ PartySearch.birthDate +"</aut:birthDate>"
				+"<aut:partyID>"+ PartySearch.partyIdentifier +"</aut:partyID>"
				+"</aut:SubjectData>"
				+"<aut:LicenseData>"
				+"<aut:licenseNumber>"+ PartySearch.licenseNumber +"</aut:licenseNumber>"
				+"<aut:licenseState>"+ PartySearch.licenseState +"</aut:licenseState>"
				+"</aut:LicenseData>"
				+"</aut:Person>"
				+"<aut:Address>"
				+"<aut:addressType>Current</aut:addressType>"
				+"<aut:line1Text>"+ PartySearch.addressLine1 +"</aut:line1Text>"
				+"<aut:zip5Code>"+PartySearch.stateCode+"</aut:zip5Code>"
				+"</aut:Address>"
				+"</aut:OriginalOrderData>"
				+"<aut:orderMvr>"+orderMVR+"</aut:orderMvr>"
				+"</aut:ViolationPredictorReport>"
				+"<aut:TransactionalData>"
				+"<aut:consumingSystemName>SOAPUI</aut:consumingSystemName>"
				+"<aut:consumerRequestPurpose>other</aut:consumerRequestPurpose>"
				+"<aut:userId>AQP506</aut:userId>"
				+"</aut:TransactionalData>"
				+"</mes:InsertViolationPredictorRequest>"
				+"<mes:Company><aut:companyCode>"+ companyCode +"</aut:companyCode><aut:division>Personal Lines</aut:division>"
				+"</mes:Company>"
				+"</mes:insertViolationPredictor>"
				+"</soapenv:Body></soapenv:Envelope>";
		
		SOAPMessage spResp = null;
		WebService obj = new WebService();

		String strEndpoint = property.getProperty("EndpointUrl_" + appln_Environment);
		System.out.println("EndpointUrl_" + strEndpoint);

		try {
			spResp = obj.getSOAPResponse(obj.getSOAPRequest(vpXML), strEndpoint);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Document doc = spResp.getSOAPBody().extractContentAsDocument();
		NodeList reportInfo = null;
		
		reportInfo = doc.getElementsByTagNameNS("*","insertViolationPredictorResponse");
		
	
		Node reportData = reportInfo.item(0);
		Element reportElement = (Element) reportData;
		String reportID = reportElement.getElementsByTagNameNS("*","reportID").item(0).getTextContent();
		System.out.println("VP Redport ID - "+reportID);
		
		LocalDateTime timeStamp = LocalDateTime.now();		
		String fieldNames = "TC_ID" + "|" + "DateTime" + "|" + "ReportType" + "|" + "ReportID";
		String dataValues = testCaseName + "|" + dtf.format(timeStamp) + "|" + "VP" + "|" + reportID;
		excelDataTable.insertRow("Results_Data", fieldNames, dataValues);
		
	}

}
